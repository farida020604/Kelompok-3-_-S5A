-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Des 2025 pada 16.35
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ecommerce`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `carts`
--

CREATE TABLE `carts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `nama` varchar(191) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `categories`
--

INSERT INTO `categories` (`id`, `nama`, `gambar`, `created_at`) VALUES
(1, 'Cireng Original', NULL, '2025-12-04 12:53:38');

-- --------------------------------------------------------

--
-- Struktur dari tabel `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `nama_biaya` varchar(100) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `total` decimal(12,2) DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `expenses`
--

INSERT INTO `expenses` (`id`, `nama_biaya`, `nama`, `total`, `tanggal`) VALUES
(1, 'listrik', NULL, 20000.00, '2025-12-25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `metode_pembayaran` varchar(50) DEFAULT NULL,
  `nama_penerima` varchar(100) DEFAULT NULL,
  `alamat_penerima` text DEFAULT NULL,
  `telepon_penerima` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `status_pengiriman` enum('dibayar','dikemas','dikirim','selesai') DEFAULT 'dibayar',
  `bukti_pembayaran` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total`, `status`, `metode_pembayaran`, `nama_penerima`, `alamat_penerima`, `telepon_penerima`, `created_at`, `status_pengiriman`, `bukti_pembayaran`) VALUES
(1, 3, 10000.00, 'success', 'QRIS / E-Wallet', 'farida', 'jl.sumur bungur', '0812131415', '2025-12-25 14:52:14', 'dikemas', NULL),
(2, 3, 10000.00, 'success', 'QRIS', 'farida', NULL, NULL, '2025-12-25 15:15:47', 'selesai', NULL),
(3, 3, 10000.00, 'success', 'QRIS', 'fraydey', 'jl,sumur bungur', '0812131415', '2025-12-25 15:23:18', 'dikemas', NULL),
(4, 3, 80000.00, 'success', 'Transfer VA', 'fraydey', 'Jl. Kebaikan', '0812131415', '2025-12-25 22:13:07', 'dikemas', NULL),
(5, 3, 20000.00, 'success', 'Transfer VA', 'carla', 'Jl. Poncol', '081211334454', '2025-12-25 22:31:47', 'dikemas', NULL),
(6, 3, 40000.00, 'success', 'QRIS', 'carla', 'Jl. Poncol 2', '081211334454', '2025-12-25 22:46:58', 'dikemas', NULL),
(7, 3, 10000.00, 'success', 'QRIS', 'rara', 'Jl. Mawar', '085718478055', '2025-12-25 23:09:46', 'selesai', 'uploads/BUKTI_7_1766679637.png'),
(8, 3, 80000.00, 'success', 'QRIS', 'syifa', 'Jl. Depok 1', '089559675870', '2025-12-25 23:47:04', 'selesai', 'uploads/BUKTI_8_1766681245.png'),
(9, 4, 20000.00, 'success', 'QRIS', 'aisyah', 'jl. smp 135', '085995667345', '2025-12-26 17:41:53', 'selesai', 'uploads/BUKTI_9_1766745732.png'),
(10, 4, 30000.00, 'success', 'Transfer VA', 'aisyah', 'Jl. Pramuka No.1 RT.01/02', '081211334455', '2025-12-27 21:28:29', 'selesai', 'uploads/BUKTI_10_1766845976.png'),
(11, 3, 20000.00, 'success', 'QRIS', 'farida', 'Jl. Radin Intan 2', '085770824880', '2025-12-27 22:24:31', 'selesai', 'uploads/BUKTI_11_1766849123.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `harga` decimal(15,2) DEFAULT NULL,
  `harga_modal` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `qty`, `harga`, `harga_modal`, `subtotal`) VALUES
(1, 1, 1, 1, 10000.00, 2000.00, 10000.00),
(2, 2, 1, 1, 10000.00, 2000.00, 10000.00),
(3, 3, 1, 1, 10000.00, 2000.00, 10000.00),
(4, 4, 1, 5, 10000.00, 2000.00, 50000.00),
(5, 4, 2, 3, 10000.00, 2000.00, 30000.00),
(6, 5, 2, 2, 10000.00, 2000.00, 20000.00),
(7, 6, 1, 4, 10000.00, 2000.00, 40000.00),
(8, 7, 2, 1, 10000.00, 2000.00, 10000.00),
(9, 8, 1, 8, 10000.00, 2000.00, 80000.00),
(10, 9, 3, 1, 10000.00, 2000.00, 10000.00),
(11, 9, 4, 1, 10000.00, 2000.00, 10000.00),
(12, 10, 1, 1, 10000.00, 2000.00, 10000.00),
(13, 10, 2, 1, 10000.00, 2000.00, 10000.00),
(14, 10, 3, 1, 10000.00, 2000.00, 10000.00),
(15, 11, 4, 2, 10000.00, 2000.00, 20000.00);

-- --------------------------------------------------------

--
-- Struktur dari tabel `payroll`
--

CREATE TABLE `payroll` (
  `id` int(11) NOT NULL,
  `nama_karyawan` varchar(100) DEFAULT NULL,
  `jabatan` varchar(50) DEFAULT NULL,
  `gaji_pokok` decimal(15,2) DEFAULT NULL,
  `tunjangan` decimal(15,2) DEFAULT NULL,
  `potongan` decimal(15,2) DEFAULT NULL,
  `bulan` varchar(20) DEFAULT NULL,
  `tanggal_bayar` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `payroll`
--

INSERT INTO `payroll` (`id`, `nama_karyawan`, `jabatan`, `gaji_pokok`, `tunjangan`, `potongan`, `bulan`, `tanggal_bayar`) VALUES
(1, 'Anggis', NULL, 500000.00, 0.00, 0.00, 'Desember 2025', '2025-12-25 14:54:14'),
(2, 'Tepung 1kg', NULL, 15000.00, 0.00, 0.00, 'Bahan Baku', '2025-12-26 00:00:00'),
(3, 'Listrik', NULL, 20000.00, 0.00, 0.00, 'Operasional', '2025-12-27 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `harga_modal` decimal(15,2) DEFAULT NULL,
  `harga` decimal(15,2) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT 'https://via.placeholder.com/300x200?text=Cireng'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `products`
--

INSERT INTO `products` (`id`, `nama`, `harga_modal`, `harga`, `stok`, `deskripsi`, `gambar`, `image_url`) VALUES
(1, 'Cireng Keju Leleh', 2000.00, 10000.00, 19, 'Cireng dengan isian keju leleh yang premium', NULL, 'uploads/1766675339.jpeg'),
(2, 'Cireng Jando', 2000.00, 10000.00, 13, 'Cireng dengan isian tetelan sapi atau jando pedas gurih dengan bumbu khas kami', NULL, 'uploads/1766675543.jpg'),
(3, 'Cireng Usus', 2000.00, 10000.00, 18, 'Cireng dengan isian usus pedas ', NULL, 'uploads/1766683505.jpg'),
(4, 'Cireng Ayam Pedas', 2000.00, 10000.00, 17, 'Cireng dengan isian ayam suwir pedas', NULL, 'uploads/1766683682.webp');

-- --------------------------------------------------------

--
-- Struktur dari tabel `settings`
--

CREATE TABLE `settings` (
  `meta_key` varchar(50) NOT NULL,
  `meta_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `settings`
--

INSERT INTO `settings` (`meta_key`, `meta_value`) VALUES
('modal_awal', '10000000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','customer') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `role`) VALUES
(1, 'Administrator', 'admin.cireng3@gmail.com', '$2y$10$w8/mYx.Uo9A1tM2VnFkUu.hZ.YFvR2o9X7E.S8H8u8h8h8h8h8h8h', 'admin'),
(2, 'Farida Customer', 'customer@gmail.com', '$2y$10$w8/mYx.Uo9A1tM2VnFkUu.hZ.YFvR2o9X7E.S8H8u8h8h8h8h8h8h', 'customer'),
(3, 'farida', 'farida@gmail.com', '$2y$10$hoLo8xd7WPftrl1gZGEK7u4HRHnB5bu4Lro81MFRfTUSnuHNcFONS', 'customer'),
(4, 'aisyah', 'aisyah@gmail.com', '$2y$10$tO08tkpKwBqtDS4kzIN.LevwxwzN40moNr/KALLu/4dfPtzkHDyLi', 'customer');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`product_id`);

--
-- Indeks untuk tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`meta_key`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT untuk tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `payroll`
--
ALTER TABLE `payroll`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
