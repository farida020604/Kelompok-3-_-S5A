<?php
/**
 * PROJECT: CHIRENG EASY
 */

session_start();
date_default_timezone_set('Asia/Jakarta');

// =============================================================================
// 1. DATABASE CONFIGURATION & INITIALIZATION
// =============================================================================
$db_host = '127.0.0.1';
$db_user = 'root';
$db_pass = '';
$db_name = 'db_ecommerce';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Proteksi jika koneksi gagal
if ($conn->connect_error) {
    die("<div style='padding:20px; border:1px solid red; color:red;'>
         <b>Koneksi Database Gagal:</b> " . $conn->connect_error . "
         <br>Pastikan MySQL Anda menyala dan database <b>$db_name</b> sudah dibuat.
         </div>");
}

// Inisialisasi folder upload untuk gambar produk dan bukti bayar
if (!file_exists('uploads')) { 
    mkdir('uploads', 0777, true); 
}

// =============================================================================
// 2. CORE HELPERS & SECURITY FUNCTIONS
// =============================================================================

/** Menghindari serangan XSS */
function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES); }

/** Cek apakah user adalah Admin */
function is_admin() { 
    return (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin'); 
}

/** Cek apakah user adalah Customer */
function is_customer() { 
    return (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'customer'); 
}

/** Format Rupiah Standar Indonesia */
function format_rp($n) { 
    return "Rp" . number_format($n, 0, ',', '.'); 
}

/** Greeting Berdasarkan Waktu */
function get_greeting() {
    $h = date('H');
    if ($h < 11) return "Selamat Pagi";
    if ($h < 15) return "Selamat Siang";
    if ($h < 19) return "Selamat Sore";
    return "Selamat Malam";
}

// =============================================================================
// 3. BACKEND CONTROLLER (LOGIC & PROCESSING)
// =============================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    // --- AUTHENTICATION: LOGIN ---
    if ($action === 'login') {
        $email = $conn->real_escape_string($_POST['email']);
        $pass = $_POST['password'];
        
        $res = $conn->query("SELECT * FROM users WHERE email='$email' LIMIT 1");
        if ($u = $res->fetch_assoc()) {
            // Support password_verify atau bypass 'admin' untuk kemudahan demo
            if (password_verify($pass, $u['password']) || $pass === 'admin') {
                $_SESSION['user'] = $u;
                header("Location: " . ($u['role'] === 'admin' ? "?page=admin_dashboard" : "?page=home"));
                exit;
            }
        }
        echo "<script>alert('Email atau Password salah!'); window.location='?page=login';</script>"; 
        exit;
    }

    // --- AUTHENTICATION: REGISTER ---
    if ($action === 'register') {
        $nama = $conn->real_escape_string($_POST['nama']);
        $email = $conn->real_escape_string($_POST['email']);
        $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $conn->query("INSERT INTO users (nama, email, password, role) VALUES ('$nama', '$email', '$pass', 'customer')");
        echo "<script>alert('Registrasi Berhasil! Silakan Login.'); window.location='?page=login';</script>";
        exit;
    }

    // --- SHOPPING SYSTEM: ADD TO CART ---
    if ($action === 'add_to_cart') {
        if (!is_customer()) { header("Location: ?page=login"); exit; }
        
        $uid = $_SESSION['user']['id'];
        $pid = intval($_POST['product_id']);
        
        // Cek ketersediaan stok di database
        $p_check = $conn->query("SELECT stok FROM products WHERE id=$pid")->fetch_assoc();
        if($p_check['stok'] > 0) {
            $conn->query("INSERT INTO carts (user_id, product_id, qty) 
                          VALUES ($uid, $pid, 1) 
                          ON DUPLICATE KEY UPDATE qty = qty + 1");
        } else {
            header("Location: ?page=home&msg=soldout"); exit;
        }
        
        if (isset($_POST['redirect']) && $_POST['redirect'] === 'cart') {
            header("Location: ?page=cart");
        } else {
            header("Location: ?page=home&msg=added");
        }
        exit;
    }

    // --- SHOPPING SYSTEM: UPDATE QTY (PLUS/MINUS) ---
    if ($action === 'update_cart_qty') {
        $cid = intval($_POST['cart_id']);
        $op = $_POST['op'];
        
        if ($op === 'plus') {
            $conn->query("UPDATE carts SET qty = qty + 1 WHERE id = $cid");
        } else {
            $conn->query("UPDATE carts SET qty = GREATEST(1, qty - 1) WHERE id = $cid");
        }
        header("Location: ?page=cart"); 
        exit;
    }

    // --- SHOPPING SYSTEM: DELETE FROM CART ---
    if ($action === 'delete_cart') {
        $conn->query("DELETE FROM carts WHERE id = ".intval($_POST['cart_id']));
        header("Location: ?page=cart"); 
        exit;
    }

    // --- SHOPPING SYSTEM: CHECKOUT ---
    if ($action === 'checkout' && is_customer()) {
        $uid = $_SESSION['user']['id'];
        $total = $_POST['total_bayar'];
        $nama = $conn->real_escape_string($_POST['nama_penerima']);
        $telp = $conn->real_escape_string($_POST['telepon_penerima']);
        $alamat = $conn->real_escape_string($_POST['alamat_penerima']);
        $metode = $_POST['metode_pembayaran'];

        // Simpan data order utama
        $conn->query("INSERT INTO orders (user_id, total, status, metode_pembayaran, nama_penerima, alamat_penerima, telepon_penerima, status_pengiriman, created_at) 
                      VALUES ($uid, $total, 'success', '$metode', '$nama', '$alamat', '$telp', 'menunggu konfirmasi', NOW())");
        $oid = $conn->insert_id;

        // Pindahkan item dari keranjang ke order_items & kurangi stok
        $cart_items = $conn->query("SELECT c.*, p.harga, p.harga_modal FROM carts c JOIN products p ON c.product_id=p.id WHERE c.user_id=$uid");
        while($it = $cart_items->fetch_assoc()) {
            $sub = $it['harga'] * $it['qty'];
            $conn->query("INSERT INTO order_items (order_id, product_id, qty, harga, harga_modal, subtotal) 
                          VALUES ($oid, {$it['product_id']}, {$it['qty']}, {$it['harga']}, {$it['harga_modal']}, $sub)");
            
            // Pengurangan stok inventaris
            $conn->query("UPDATE products SET stok = stok - {$it['qty']} WHERE id = {$it['product_id']}");
        }
        
        // Bersihkan keranjang
        $conn->query("DELETE FROM carts WHERE user_id=$uid");
        header("Location: ?page=invoice&id=$oid"); 
        exit;
    }

    // --- UPLOAD: BUKTI PEMBAYARAN ---
    if ($action === 'upload_bukti' && is_customer()) {
        $oid = intval($_POST['order_id']);
        if (!empty($_FILES['bukti_bayar']['name'])) {
            $ext = pathinfo($_FILES['bukti_bayar']['name'], PATHINFO_EXTENSION);
            $filename = "BUKTI_" . $oid . "_" . time() . "." . $ext;
            
            if (move_uploaded_file($_FILES['bukti_bayar']['tmp_name'], 'uploads/' . $filename)) {
                $path = 'uploads/' . $filename;
                $conn->query("UPDATE orders SET bukti_pembayaran = '$path' WHERE id = $oid");
                header("Location: ?page=invoice&id=$oid&msg=success");
            }
        }
        exit;
    }

    // --- ADMIN: INVENTORY MANAGEMENT ---
    if ($action === 'save_product' && is_admin()) {
        $id = $_POST['id'];
        $nama = $conn->real_escape_string($_POST['nama']);
        $modal = $_POST['harga_modal'];
        $jual = $_POST['harga_jual'];
        $stok = $_POST['stok'];
        $desk = $conn->real_escape_string($_POST['deskripsi']);
        
        $img_path = $_POST['existing_img'] ?? '';
        if (!empty($_FILES['image_file']['name'])) {
            $ext = pathinfo($_FILES['image_file']['name'], PATHINFO_EXTENSION);
            $filename = "PROD_" . time() . '.' . $ext;
            move_uploaded_file($_FILES['image_file']['tmp_name'], 'uploads/' . $filename);
            $img_path = 'uploads/' . $filename;
        }

        if ($id) {
            $conn->query("UPDATE products SET nama='$nama', harga_modal=$modal, harga=$jual, stok=$stok, image_url='$img_path', deskripsi='$desk' WHERE id=$id");
        } else {
            $conn->query("INSERT INTO products (nama, harga_modal, harga, stok, image_url, deskripsi) VALUES ('$nama', $modal, $jual, $stok, '$img_path', '$desk')");
        }
        header("Location: ?page=admin_products"); 
        exit;
    }

    // --- ADMIN: UPDATE ORDER STATUS ---
    if ($action === 'update_status' && is_admin()) {
        $oid = intval($_POST['order_id']);
        $stat = $_POST['status_pengiriman'];
        $conn->query("UPDATE orders SET status_pengiriman = '$stat' WHERE id = $oid");
        header("Location: ?page=admin_orders"); 
        exit;
    }

    // --- ADMIN: SAVE EXPENSE (PAYROLL) ---
    if ($action === 'save_expense' && is_admin()) {
        $ket = $conn->real_escape_string($_POST['keterangan']);
        $jumlah = $_POST['jumlah'];
        $kat = $_POST['kategori'];
        $tgl = $_POST['tanggal'];
        
        // Simpan ke tabel payroll (digunakan sebagai tabel pengeluaran umum)
        $conn->query("INSERT INTO payroll (nama_karyawan, gaji_pokok, tunjangan, potongan, bulan, tanggal_bayar) 
                      VALUES ('$ket', $jumlah, 0, 0, '$kat', '$tgl')");
        header("Location: ?page=admin_payroll"); 
        exit;
    }
}

// LOGOUT HANDLER
if (isset($_GET['action']) && $_GET['action'] === 'logout') { 
    session_destroy(); 
    header("Location: ?page=login"); 
    exit; 
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chireng Easy - E-Commerce</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root { 
            --shopee: #ee4d2d; 
            --sidebar: #2c3e50; 
            --bg: #f4f7f6; 
            --success-glow: rgba(40, 167, 69, 0.2);
        }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background-color: var(--bg); 
            color: #333; 
            overflow-x: hidden;
        }

        /* ADMIN SIDEBAR */
        .admin-sidebar { 
            width: 260px; 
            background: var(--sidebar); 
            height: 100vh; 
            position: fixed; 
            left: 0; 
            top: 0; 
            padding-top: 20px; 
            z-index: 1000; 
            box-shadow: 4px 0 10px rgba(0,0,0,0.1);
        }
        .admin-sidebar a { 
            padding: 14px 25px; 
            display: block; 
            color: #adb5bd; 
            text-decoration: none; 
            font-size: 0.9rem; 
            transition: 0.3s;
        }
        .admin-sidebar a:hover, .admin-sidebar a.active { 
            color: white; 
            background: rgba(255,255,255,0.05); 
            border-left: 4px solid var(--shopee); 
        }
        .admin-main { margin-left: 260px; padding: 40px; min-height: 100vh; }

        /* CUSTOM NAVBAR */
        .navbar-custom { 
            background: white; 
            border-bottom: 2px solid var(--shopee); 
            padding: 12px 0; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.05); 
        }
        
        /* BANNER & CARDS */
        .hero-banner { 
            background: linear-gradient(135deg, #ee4d2d 0%, #ff7337 100%); 
            color: white; 
            border-radius: 24px; 
            padding: 60px 40px; 
            margin-bottom: 40px; 
            position: relative; 
            overflow: hidden; 
        }
        .card-product { 
            border: none; 
            border-radius: 16px; 
            transition: all 0.3s ease; 
            overflow: hidden; 
            height: 100%; 
            background: white;
        }
        .card-product:hover { 
            transform: translateY(-8px); 
            box-shadow: 0 15px 30px rgba(0,0,0,0.12); 
        }
        .card-product img { height: 200px; width: 100%; object-fit: cover; }
        
        /* BUTTONS & BADGES */
        .btn-shopee { 
            background: var(--shopee); 
            color: white; 
            border-radius: 50px; 
            border: none; 
            padding: 10px 24px; 
            font-weight: 600; 
            transition: 0.3s;
        }
        .btn-shopee:hover { background: #d73211; color: white; transform: scale(1.02); }
        .badge-stok { 
            position: absolute; 
            top: 15px; 
            left: 15px; 
            z-index: 10; 
            padding: 6px 12px; 
            border-radius: 50px; 
            font-size: 11px; 
            font-weight: 700; 
            text-transform: uppercase;
        }

        /* SHOPPING TOOLS */
        .qty-btn { 
            width: 32px; height: 32px; 
            display: flex; align-items: center; justify-content: center; 
            border: 1px solid #dee2e6; background: white; border-radius: 8px; 
            cursor: pointer; transition: 0.2s;
        }
        .qty-btn:hover { background: #f8f9fa; border-color: var(--shopee); color: var(--shopee); }

        /* INVOICE DESIGN */
        .invoice-box { 
            background: white; 
            padding: 50px; 
            border-radius: 20px; 
            border-top: 12px solid var(--shopee); 
            box-shadow: 0 20px 40px rgba(0,0,0,0.06); 
        }

        /* UTILITIES */
        .realtime-clock { font-weight: 600; color: var(--sidebar); background: #e9ecef; padding: 5px 15px; border-radius: 50px; font-size: 0.85rem; }
        
        @media print { 
            .no-print { display: none !important; } 
            .admin-main { margin-left: 0; padding: 0; }
            .invoice-box { box-shadow: none; border: 1px solid #ddd; }
        }
        
        @media (max-width: 768px) {
            .admin-sidebar { width: 70px; }
            .admin-sidebar a span { display: none; }
            .admin-sidebar a i { margin: 0 !important; font-size: 1.2rem; }
            .admin-main { margin-left: 70px; padding: 15px; }
        }
    </style>
</head>
<body>

<?php if (is_admin()): ?>
    <div class="admin-sidebar no-print">
        <div class="px-4 mb-4 text-center text-white">
            <h4 class="fw-bold mb-0"><i class="fa fa-fire text-warning"></i> ADMIN</h4>
            <small class="opacity-50">CHIRENG EASY</small>
        </div>
        <div class="mt-4">
            <a href="?page=admin_dashboard" class="<?= ($_GET['page']??'')=='admin_dashboard'?'active':'' ?>">
                <i class="fa fa-chart-pie me-3"></i> <span>Dashboard Utama</span>
            </a>
            <a href="?page=admin_products" class="<?= ($_GET['page']??'')=='admin_products'?'active':'' ?>">
                <i class="fa fa-boxes me-3"></i> <span>Manajemen Stok</span>
            </a>
            <a href="?page=admin_orders" class="<?= ($_GET['page']??'')=='admin_orders'?'active':'' ?>">
                <i class="fa fa-shopping-cart me-3"></i> <span>Pesanan Masuk</span>
            </a>
            <a href="?page=admin_payroll" class="<?= ($_GET['page']??'')=='admin_payroll'?'active':'' ?>">
                <i class="fa fa-file-invoice-dollar me-3"></i> <span>Biaya Operasional</span>
            </a>
            <a href="?page=admin_finance" class="<?= ($_GET['page']??'')=='admin_finance'?'active':'' ?>">
                <i class="fa fa-wallet me-3"></i> <span>Laporan Keuangan</span>
            </a>
            <hr class="mx-3 border-secondary opacity-25">
            <a href="?page=home" class="text-info"><i class="fa fa-eye me-3"></i> <span>Lihat Toko</span></a>
            <a href="?action=logout" class="text-danger"><i class="fa fa-power-off me-3"></i> <span>Logout</span></a>
        </div>
    </div>
<?php else: ?>
    <?php if(!in_array(($_GET['page']??''), ['login','register'])): ?>
    <nav class="navbar navbar-expand-lg navbar-light navbar-custom sticky-top no-print">
        <div class="container">
            <a href="?page=home" class="navbar-brand fw-bold fs-3 d-flex align-items-center" style="color:var(--shopee)">
                <i class="fa fa-fire me-2"></i> Beranda
            </a>
            
            <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navSearch">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navSearch">
                <form action="index.php" method="GET" class="ms-lg-5 me-auto mt-3 mt-lg-0 w-50">
                    <input type="hidden" name="page" value="home">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control rounded-pill-start border-end-0 shadow-none px-4 py-2" 
                               placeholder="Cari cireng favoritmu..." value="<?= h($_GET['search'] ?? '') ?>">
                        <button class="btn btn-outline-secondary rounded-pill-end border-start-0 px-3 bg-white text-muted" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </form>

                <div class="d-flex align-items-center gap-4 mt-3 mt-lg-0">
                    <div class="realtime-clock d-none d-md-block" id="serverClock">00:00:00</div>
                    
                    <?php if (is_customer()): ?>
                        <a href="?page=cart" class="text-dark text-decoration-none position-relative">
                            <i class="fa fa-shopping-bag fs-5"></i>
                            <?php 
                            $cart_count = $conn->query("SELECT id FROM carts WHERE user_id=".$_SESSION['user']['id'])->num_rows; 
                            if($cart_count > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 10px; border: 2px solid white;">
                                <?= $cart_count ?>
                            </span>
                            <?php endif; ?>
                        </a>
                        <a href="?page=my_orders" class="text-dark text-decoration-none small fw-bold">Pesanan Saya</a>
                        <div class="dropdown">
                            <button class="btn btn-light rounded-pill px-3 dropdown-toggle" data-bs-toggle="dropdown">
                                Hi, <?= explode(' ', h($_SESSION['user']['nama']))[0] ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end border-0 shadow-lg mt-2">
                                <?php if(is_admin()): ?><li><a class="dropdown-item" href="?page=admin_dashboard">Panel Admin</a></li><?php endif; ?>
                                <li><a class="dropdown-item text-danger" href="?action=logout">Keluar</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="?page=login" class="btn btn-shopee shadow-sm">Mulai Belanja</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
    <?php endif; ?>
<?php endif; ?>

<div class="<?= is_admin() ? 'admin-main' : 'container py-5' ?>">
<?php
$page = $_GET['page'] ?? 'home';

// ==========================================
// ROUTER: LOGIN PAGE
// ==========================================
if ($page === 'login'): ?>
    <div class="row justify-content-center pt-5">
        <div class="col-md-4">
            <div class="card border-0 shadow-lg p-4 rounded-4 mt-5">
                <div class="text-center mb-4">
                    <div class="bg-light d-inline-block p-3 rounded-circle mb-3"><i class="fa fa-user-lock fs-2 text-shopee"></i></div>
                    <h3 class="fw-bold">Selamat Datang</h3>
                    <p class="text-muted small">Akses akun Chireng Easy Anda</p>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="login">
                    <div class="mb-3">
                        <label class="small fw-bold text-muted mb-1">Email Address</label>
                        <input type="email" name="email" class="form-control py-2 shadow-none" placeholder="username" required>
                    </div>
                    <div class="mb-4">
                        <label class="small fw-bold text-muted mb-1">Password</label>
                        <input type="password" name="password" class="form-control py-2 shadow-none" placeholder="password" required>
                    </div>
                    <button class="btn btn-shopee w-100 py-2 shadow-sm">MASUK SEKARANG</button>
                </form>
                <div class="text-center small mt-4">Belum punya akun? <a href="?page=register" class="text-danger fw-bold text-decoration-none">Daftar Akun Baru</a></div>
            </div>
        </div>
    </div>

<?php 
// ==========================================
// ROUTER: REGISTER PAGE
// ==========================================
elseif ($page === 'register'): ?>
    <div class="row justify-content-center pt-5">
        <div class="col-md-4">
            <div class="card border-0 shadow-lg p-4 rounded-4 mt-5">
                <div class="text-center mb-4">
                    <h3 class="fw-bold">Daftar Akun</h3>
                    <p class="text-muted small">Lengkapi data untuk mulai berbelanja</p>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="register">
                    <div class="mb-3">
                        <label class="small fw-bold text-muted mb-1">Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control py-2 shadow-none" required>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold text-muted mb-1">Email</label>
                        <input type="email" name="email" class="form-control py-2 shadow-none" required>
                    </div>
                    <div class="mb-4">
                        <label class="small fw-bold text-muted mb-1">Password</label>
                        <input type="password" name="password" class="form-control py-2 shadow-none" required>
                    </div>
                    <button class="btn btn-shopee w-100 py-2 shadow-sm">DAFTARKAN SAYA</button>
                </form>
                <div class="text-center small mt-3"><a href="?page=login" class="text-muted">Sudah punya akun? Login</a></div>
            </div>
        </div>
    </div>

<?php 
// ==========================================
// ROUTER: HOME (CATALOG & BANNER)
// ==========================================
elseif ($page === 'home'): ?>
    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-4 mb-4 border-0 shadow-sm" role="alert">
            <i class="fa fa-check-circle me-2"></i> 
            <?= $_GET['msg'] === 'added' ? 'Produk berhasil masuk ke keranjang belanja!' : 'Maaf, stok produk sedang habis.' ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="hero-banner shadow-sm">
        <div class="row align-items-center">
            <div class="col-md-7 position-relative" style="z-index: 2;">
                <span class="badge bg-white text-shopee mb-3 rounded-pill px-3 py-2 fw-bold">PROMO HARI INI</span>
                <h1 class="fw-bold display-5 mb-2">Chireng Easy</h1>
                <p class="lead opacity-90 mb-4">"Nikmati sensasi cireng isi dengan berbagai varian rasa premium. Easy Dimakan, Susah Dilupakan."</p>
                <div class="d-flex gap-2">
                    <a href="#katalog" class="btn btn-light text-shopee fw-bold rounded-pill px-4 shadow-sm">Lihat Menu</a>
                
                </div>
            </div>
            <div class="col-md-5 d-none d-md-block text-center">
                 <i class="fa fa-fire opacity-25" style="font-size: 200px;"></i>
            </div>
        </div>
    </div>

    <div id="katalog" class="d-flex justify-content-between align-items-end mb-4">
        <div>
            <h3 class="fw-bold mb-0">Menu Spesial</h3>
            <p class="text-muted small mb-0">Pilihan cireng terbaik untuk hari Anda</p>
        </div>
        <div class="text-muted small">Menampilkan: <b><?= isset($_GET['search']) ? "Hasil pencarian '".h($_GET['search'])."'" : "Semua Produk" ?></b></div>
    </div>

    <div class="row g-4">
        <?php 
        $s = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
        $res = $conn->query("SELECT * FROM products WHERE nama LIKE '%$s%' OR deskripsi LIKE '%$s%' ORDER BY id DESC"); 
        
        if($res->num_rows === 0): ?>
            <div class="col-12 text-center py-5">
                <i class="fa fa-search-minus fs-1 text-muted mb-3"></i>
                <h5>Ups! Produk tidak ditemukan</h5>
                <p class="text-muted">Coba gunakan kata kunci pencarian yang lain.</p>
            </div>
        <?php endif;
        
        while($p = $res->fetch_assoc()): ?>
            <div class="col-6 col-md-3">
                <div class="card card-product shadow-sm">
                    <?php if($p['stok'] <= 0): ?>
                        <span class="badge bg-dark badge-stok">Habis</span>
                    <?php elseif($p['stok'] < 10): ?>
                        <span class="badge bg-danger badge-stok">Sisa <?= $p['stok'] ?></span>
                    <?php else: ?>
                        <span class="badge bg-success badge-stok opacity-75">Tersedia</span>
                    <?php endif; ?>

                    <img src="<?= $p['image_url'] ?: 'https://via.placeholder.com/300x200?text=No+Image' ?>" class="card-img-top">
                    
                    <div class="card-body p-3">
                        <h6 class="fw-bold text-truncate mb-1" title="<?= h($p['nama']) ?>"><?= h($p['nama']) ?></h6>
                        <p class="text-muted small mb-3 text-truncate"><?= h($p['deskripsi'] ?: 'Cireng gurih khas Bandung') ?></p>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="fw-bold text-shopee mb-0"><?= format_rp($p['harga']) ?></h5>
                        </div>
                        <div class="d-flex gap-2">
                            <form method="POST" class="flex-grow-1">
                                <input type="hidden" name="action" value="add_to_cart">
                                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                                <button class="btn btn-outline-danger btn-sm w-100 rounded-pill <?= $p['stok'] <= 0 ? 'disabled' : '' ?>" title="Tambah ke Keranjang">
                                    <i class="fa fa-cart-plus"></i>
                                </button>
                            </form>
                            <form method="POST" class="flex-grow-2 w-100">
                                <input type="hidden" name="action" value="add_to_cart">
                                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                                <input type="hidden" name="redirect" value="cart">
                                <button class="btn btn-shopee btn-sm w-100 rounded-pill <?= $p['stok'] <= 0 ? 'disabled' : '' ?>">Beli</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

<?php 
// ==========================================
// ROUTER: ADMIN DASHBOARD (ANALYTICS)
// ==========================================
elseif ($page === 'admin_dashboard' && is_admin()): 
    // Kalkulasi Angka Dashboard
    $omzet_res = $conn->query("SELECT SUM(total) as n FROM orders WHERE status_pengiriman IN ('dikemas', 'dikirim', 'selesai')");
    $total_omzet = $omzet_res->fetch_assoc()['n'] ?? 0;
    
    $expense_res = $conn->query("SELECT SUM(gaji_pokok) as n FROM payroll");
    $total_pengeluaran = $expense_res->fetch_assoc()['n'] ?? 0;
    
    // Hitung Modal dari produk yang terjual (Status Valid)
    $modal_res = $conn->query("SELECT SUM(oi.harga_modal * oi.qty) as n FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE o.status_pengiriman != 'menunggu konfirmasi'");
    $total_modal_terjual = $modal_res->fetch_assoc()['n'] ?? 0;
    
    // RUMUS LABA BERSIH
    $laba_bersih = ($total_omzet - $total_modal_terjual) - $total_pengeluaran;

    $order_hari_ini = $conn->query("SELECT COUNT(*) as n FROM orders WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['n'] ?? 0;

    $current_sort = $_GET['sort'] ?? 'desc';
    $sort_sql = strtoupper($current_sort);
?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Analisis Bisnis</h3>
            <p class="text-muted small">Update statistik per: <b><?= date('d M Y, H:i') ?></b></p>
        </div>
        <button onclick="window.print()" class="btn btn-outline-dark btn-sm rounded-pill px-3 no-print">
            <i class="fa fa-print me-2"></i>Cetak Laporan
        </button>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-white rounded-4 border-start border-primary border-5">
                <small class="text-muted fw-bold">TOTAL OMZET</small>
                <h4 class="fw-bold text-primary mb-0 mt-1"><?= format_rp($total_omzet) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-white rounded-4 border-start border-danger border-5">
                <small class="text-muted fw-bold">OPERASIONAL</small>
                <h4 class="fw-bold text-danger mb-0 mt-1"><?= format_rp($total_pengeluaran) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-success text-white rounded-4">
                <small class="opacity-75 fw-bold">ESTIMASI LABA BERSIH</small>
                <h4 class="fw-bold mb-0 mt-1"><?= format_rp($laba_bersih) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-dark text-white rounded-4">
                <small class="opacity-75 fw-bold">ORDER HARI INI</small>
                <h4 class="fw-bold mb-0 mt-1"><?= $order_hari_ini ?> Pesanan</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="fw-bold mb-0"><i class="fa fa-chart-line me-2 text-shopee"></i>Tren Penjualan (7 Hari Terakhir)</h5>
                </div>
                <canvas id="salesChart" height="150"></canvas>
            </div>
            
            <div class="card border-0 shadow-sm p-4 rounded-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">Data Penjualan Produk</h5>
                    <div class="dropdown no-print">
                        <button class="btn btn-sm btn-light border dropdown-toggle rounded-pill px-3" data-bs-toggle="dropdown">
                            Sortir: <?= $current_sort == 'desc' ? 'Terbanyak' : 'Sedikit' ?>
                        </button>
                        <ul class="dropdown-menu border-0 shadow-lg">
                            <li><a class="dropdown-item" href="?page=admin_dashboard&sort=desc">Unit Terbanyak</a></li>
                            <li><a class="dropdown-item" href="?page=admin_dashboard&sort=asc">Unit Terendah</a></li>
                        </ul>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead class="table-light"><tr class="small text-muted"><th>Nama Produk</th><th class="text-center">Unit Terjual</th><th class="text-end">Pendapatan Bersih</th></tr></thead>
                        <tbody>
                            <?php 
                            $rank = $conn->query("SELECT p.nama, SUM(oi.qty) as total_qty, SUM(oi.subtotal) as total_duit 
                                                  FROM order_items oi 
                                                  JOIN products p ON oi.product_id = p.id 
                                                  JOIN orders o ON oi.order_id = o.id 
                                                  WHERE o.status_pengiriman != 'menunggu konfirmasi' 
                                                  GROUP BY p.id ORDER BY total_qty $sort_sql");
                            
                            if($rank->num_rows === 0) echo "<tr><td colspan='3' class='text-center py-3 text-muted'>Belum ada data penjualan.</td></tr>";
                            
                            while($r = $rank->fetch_assoc()): ?>
                            <tr>
                                <td><span class="small fw-bold"><?= h($r['nama']) ?></span></td>
                                <td class="text-center"><span class="badge bg-light text-dark border rounded-pill"><?= $r['total_qty'] ?> Unit</span></td>
                                <td class="text-end small fw-bold text-shopee"><?= format_rp($r['total_duit']) ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                <h6 class="fw-bold mb-3"><i class="fa fa-exclamation-triangle me-2 text-warning"></i>Stok Menipis</h6>
                <?php 
                $res=$conn->query("SELECT nama, stok FROM products WHERE stok < 10 ORDER BY stok ASC LIMIT 5"); 
                if($res->num_rows === 0): ?>
                    <p class="small text-success mb-0">Semua stok aman.</p>
                <?php endif;
                while($s=$res->fetch_assoc()): ?>
                <div class="d-flex justify-content-between align-items-center mb-3 p-2 bg-light rounded-3">
                    <span class="small text-dark fw-semibold"><?= h($s['nama']) ?></span>
                    <span class="badge <?= $s['stok'] <= 3 ? 'bg-danger' : 'bg-warning text-dark' ?>"><?= $s['stok'] ?> unit</span>
                </div>
                <?php endwhile; ?>
                <a href="?page=admin_products" class="btn btn-sm btn-outline-secondary w-100 mt-2 rounded-pill">Kelola Stok</a>
            </div>

            <div class="card border-0 shadow-sm p-4 rounded-4 bg-primary text-white">
                <h6 class="fw-bold mb-2">Tips Manajemen</h6>
                <p class="small opacity-75 mb-0">Pastikan untuk mengecek bukti pembayaran secara teliti sebelum mengubah status pesanan menjadi <b>Dikemas</b>.</p>
            </div>
        </div>
    </div>

<?php 
// ==========================================
// ROUTER: SHOPPING CART (CUSTOMER)
// ==========================================
elseif ($page === 'cart' && is_customer()): ?>
    <h3 class="fw-bold mb-4">Keranjang Belanja</h3>
    <?php 
    $res=$conn->query("SELECT c.*, p.nama, p.harga, p.image_url FROM carts c JOIN products p ON c.product_id=p.id WHERE c.user_id=".$_SESSION['user']['id']);
    if($res->num_rows === 0): ?>
        <div class="text-center py-5 bg-white rounded-4 shadow-sm">
            <i class="fa fa-shopping-basket fs-1 text-muted mb-3"></i>
            <h5>Keranjang Anda Kosong</h5>
            <p class="text-muted">Ayo tambah beberapa cireng enak ke sini!</p>
            <a href="?page=home" class="btn btn-shopee">Belanja Sekarang</a>
        </div>
    <?php else: ?>
    <div class="row g-4">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm p-4 rounded-4">
                <table class="table align-middle">
                    <thead><tr class="text-muted small border-bottom"><th>Produk</th><th>Harga</th><th class="text-center">Kuantitas</th><th>Subtotal</th><th></th></tr></thead>
                    <tbody>
                        <?php $gt=0; 
                        while($c = $res->fetch_assoc()): 
                            $sub=$c['harga']*$c['qty']; 
                            $gt+=$sub; 
                        ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <img src="<?= $c['image_url'] ?>" width="55" class="rounded shadow-sm">
                                    <strong class="small"><?= h($c['nama']) ?></strong>
                                </div>
                            </td>
                            <td class="small"><?= format_rp($c['harga']) ?></td>
                            <td>
                                <div class="d-flex align-items-center justify-content-center gap-2">
                                    <form method="POST"><input type="hidden" name="action" value="update_cart_qty"><input type="hidden" name="cart_id" value="<?= $c['id'] ?>"><input type="hidden" name="op" value="minus"><button class="qty-btn">-</button></form>
                                    <span class="fw-bold mx-2"><?= $c['qty'] ?></span>
                                    <form method="POST"><input type="hidden" name="action" value="update_cart_qty"><input type="hidden" name="cart_id" value="<?= $c['id'] ?>"><input type="hidden" name="op" value="plus"><button class="qty-btn">+</button></form>
                                </div>
                            </td>
                            <td class="fw-bold text-shopee"><?= format_rp($sub) ?></td>
                            <td>
                                <form method="POST" onsubmit="return confirm('Hapus item ini?')">
                                    <input type="hidden" name="action" value="delete_cart">
                                    <input type="hidden" name="cart_id" value="<?= $c['id'] ?>">
                                    <button class="btn btn-sm text-danger opacity-50"><i class="fa fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <div class="mt-3">
                    <a href="?page=home" class="btn btn-sm btn-light rounded-pill"><i class="fa fa-arrow-left me-2"></i>Kembali Belanja</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-4 rounded-4">
                <h5 class="fw-bold mb-4">Informasi Pengiriman</h5>
                <form method="POST">
                    <input type="hidden" name="action" value="checkout">
                    <input type="hidden" name="total_bayar" value="<?= $gt ?>">
                    <div class="mb-3">
                        <label class="small fw-bold text-muted">Penerima</label>
                        <input type="text" name="nama_penerima" class="form-control shadow-none" placeholder="Nama Lengkap" required>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold text-muted">No. Telepon</label>
                        <input type="text" name="telepon_penerima" class="form-control shadow-none" placeholder="08xxx" required>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold text-muted">Alamat Lengkap</label>
                        <textarea name="alamat_penerima" class="form-control shadow-none" rows="3" placeholder="Jl. Raya No..." required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold text-muted">Metode Pembayaran</label>
                        <select name="metode_pembayaran" class="form-select shadow-none" onchange="toggleQR(this.value)">
                            <option value="Transfer">Transfer Bank</option>
                            <option value="QRIS">QRIS</option>
                        </select>
                    </div>
                    
                    <div id="qris_box" class="text-center d-none border rounded-3 p-3 mb-3 bg-light animate__animated animate__fadeIn">
                        <p class="small fw-bold mb-2">Scan QRIS Chireng Easy</p>
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=CHIRENGPAY_<?= time() ?>" class="img-fluid rounded border shadow-sm mb-2">
                        <p class="x-small text-muted mb-0">Screenshot & Bayar via m-Banking/E-Wallet</p>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4 pt-3 border-top">
                        <span class="text-muted">Total Bayar:</span>
                        <h4 class="fw-bold text-shopee mb-0"><?= format_rp($gt) ?></h4>
                    </div>
                    <button class="btn btn-shopee w-100 py-3 rounded-pill shadow">BUAT PESANAN</button>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

<?php 
// ==========================================
// ROUTER: MY ORDERS (HISTORY)
// ==========================================
elseif ($page === 'my_orders' && is_customer()): ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold">Riwayat Pesanan</h3>
        <span class="badge bg-white text-dark border px-3 py-2 rounded-pill"><?= $_SESSION['user']['nama'] ?></span>
    </div>
    
    <div class="row g-3">
        <?php 
        $res = $conn->query("SELECT * FROM orders WHERE user_id=".$_SESSION['user']['id']." ORDER BY id DESC"); 
        if($res->num_rows === 0): ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted">Belum ada pesanan yang dibuat.</p>
            </div>
        <?php endif;
        while($o = $res->fetch_assoc()): 
            $status_raw = $o['status_pengiriman'];
            $badge_color = 'bg-secondary';
            if($status_raw == 'menunggu konfirmasi') $badge_color = 'bg-warning text-dark';
            elseif($status_raw == 'dikemas') $badge_color = 'bg-info text-white';
            elseif($status_raw == 'dikirim') $badge_color = 'bg-primary';
            elseif($status_raw == 'selesai') $badge_color = 'bg-success';
        ?>
        <div class="col-md-6">
            <div class="card border-0 shadow-sm p-4 rounded-4 position-relative overflow-hidden">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div>
                        <span class="small text-muted d-block mb-1">ID PESANAN</span>
                        <h6 class="fw-bold">#INV-<?= $o['id'] ?></h6>
                    </div>
                    <span class="badge <?= $badge_color ?> rounded-pill px-3 py-2" style="font-size: 11px;">
                        <?= strtoupper($status_raw) ?>
                    </span>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        <span class="small text-muted d-block">Total Pembayaran</span>
                        <h5 class="fw-bold text-shopee mb-0"><?= format_rp($o['total']) ?></h5>
                    </div>
                    <a href="?page=invoice&id=<?= $o['id'] ?>" class="btn btn-dark btn-sm rounded-pill px-4">Lihat Detail</a>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

<?php 
// ==========================================
// ROUTER: INVOICE & DETAIL PESANAN
// ==========================================
elseif ($page === 'invoice'): 
    $oid = intval($_GET['id'] ?? 0); 
    $q = $conn->query("SELECT * FROM orders WHERE id=$oid");
    if($q->num_rows === 0) { echo "Pesanan tidak ditemukan."; return; }
    
    $o = $q->fetch_assoc(); 
    $status_db = $o['status_pengiriman'] ?: 'menunggu konfirmasi';
?>
<div class="row justify-content-center">
    <div class="col-md-8 col-lg-7">
        <div class="invoice-box">
            <div class="row align-items-center mb-5">
                <div class="col-6">
                    <h2 class="fw-bold text-shopee mb-0">INVOICE</h2>
                    <p class="text-muted mb-0">Chireng Easy E-Commerce</p>
                </div>
                <div class="col-6 text-end">
                    <h6 class="fw-bold text-muted mb-0">#INV-<?= $o['id'] ?></h6>
                    <small class="text-muted"><?= date('d F Y', strtotime($o['created_at'])) ?></small>
                </div>
            </div>

            <div class="row mb-5">
                <div class="col-6">
                    <p class="text-muted small fw-bold mb-2">DETAIL PENERIMA</p>
                    <h6 class="fw-bold mb-1"><?= h($o['nama_penerima']) ?></h6>
                    <p class="text-muted small mb-1"><?= h($o['telepon_penerima']) ?></p>
                    <p class="text-muted small"><?= h($o['alamat_penerima']) ?></p>
                </div>
                <div class="col-6 text-end">
                    <p class="text-muted small fw-bold mb-2">STATUS PESANAN</p>
                    <span class="badge <?= ($status_db == 'menunggu konfirmasi') ? 'bg-warning text-dark' : 'bg-primary' ?> px-3 py-2 rounded-pill">
                        <?= strtoupper($status_db) ?>
                    </span>
                    <p class="small text-muted mt-2">Metode: <b><?= $o['metode_pembayaran'] ?></b></p>
                </div>
            </div>

            <table class="table table-borderless">
                <thead class="border-bottom"><tr class="text-muted small"><th>NAMA ITEM</th><th class="text-center">QTY</th><th class="text-end">HARGA</th><th class="text-end">SUBTOTAL</th></tr></thead>
                <tbody>
                    <?php 
                    $items = $conn->query("SELECT oi.*, p.nama FROM order_items oi JOIN products p ON oi.product_id=p.id WHERE oi.order_id=$oid"); 
                    while($it = $items->fetch_assoc()): ?>
                    <tr class="small border-bottom border-light">
                        <td class="py-3"><b><?= h($it['nama']) ?></b></td>
                        <td class="text-center py-3"><?= $it['qty'] ?></td>
                        <td class="text-end py-3"><?= format_rp($it['harga']) ?></td>
                        <td class="text-end py-3 fw-bold"><?= format_rp($it['subtotal']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="3" class="text-end py-4">TOTAL PEMBAYARAN</th>
                        <th class="text-end py-4 text-shopee fs-4 fw-bold"><?= format_rp($o['total']) ?></th>
                    </tr>
                </tfoot>
            </table>

            <?php if($status_db == 'menunggu konfirmasi' && is_customer()): ?>
                <div class="card border-0 shadow-sm mt-5 p-4 bg-light rounded-4 no-print text-center">
                    <h6 class="fw-bold mb-3"><i class="fa fa-cloud-upload text-shopee me-2"></i>Konfirmasi Pembayaran</h6>
                    <p class="small text-muted mb-4">Silakan unggah foto bukti transfer atau bukti scan QRIS Anda di bawah ini.</p>
                    
                    <?php if(!empty($o['bukti_pembayaran'])): ?>
                        <div class="mb-4">
                            <label class="d-block small text-muted mb-2">Bukti Saat Ini:</label>
                            <img src="<?= $o['bukti_pembayaran'] ?>" class="img-thumbnail rounded-3" style="max-height: 200px">
                        </div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data" class="text-start">
                        <input type="hidden" name="action" value="upload_bukti">
                        <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                        <div class="mb-3">
                            <input type="file" name="bukti_bayar" class="form-control shadow-none rounded-pill" required accept="image/*">
                        </div>
                        <button class="btn btn-shopee w-100 py-2 fw-bold shadow-sm rounded-pill">
                            UNGGAH SEKARANG
                        </button>
                    </form>
                </div>
            <?php endif; ?>

            <div class="mt-5 text-center no-print">
                <button onclick="window.print()" class="btn btn-dark px-4 rounded-pill me-2">
                    <i class="fa fa-print me-2"></i>Cetak Ke PDF
                </button>
                <a href="?page=my_orders" class="btn btn-light border px-4 rounded-pill">Kembali ke Riwayat</a>
            </div>
        </div>
        <p class="text-center text-muted small mt-4 no-print">Terima kasih telah berbelanja di <b>Chireng Easy</b>!</p>
    </div>
</div>

<?php 
// ==========================================
// ROUTER: ADMIN PRODUCTS (INVENTORY)
// ==========================================
elseif ($page === 'admin_products' && is_admin()): ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold">Manajemen Inventaris</h3>
        <button class="btn btn-shopee rounded-pill" onclick="showProductModal()">
            <i class="fa fa-plus-circle me-2"></i>Tambah Produk Baru
        </button>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light"><tr><th class="ps-4">Foto</th><th>Informasi Produk</th><th>Harga Modal</th><th>Harga Jual</th><th>Stok</th><th class="text-center">Aksi</th></tr></thead>
                <tbody>
                    <?php $res=$conn->query("SELECT * FROM products ORDER BY id DESC"); 
                    while($p=$res->fetch_assoc()): ?>
                    <tr>
                        <td class="ps-4"><img src="<?= $p['image_url'] ?>" width="55" height="55" class="rounded shadow-sm object-fit-cover"></td>
                        <td>
                            <strong class="d-block"><?= h($p['nama']) ?></strong>
                            <small class="text-muted d-block text-truncate" style="max-width: 200px;"><?= h($p['deskripsi']) ?></small>
                        </td>
                        <td class="text-muted"><?= format_rp($p['harga_modal']) ?></td>
                        <td class="text-shopee fw-bold"><?= format_rp($p['harga']) ?></td>
                        <td>
                            <span class="badge <?= $p['stok'] < 5 ? 'bg-danger':'bg-secondary' ?> rounded-pill px-3">
                                <?= $p['stok'] ?> Unit
                            </span>
                        </td>
                        <td class="text-center">
                            <button class="btn btn-sm btn-light border rounded-pill px-3" onclick='editProduct(<?= json_encode($p) ?>)'>
                                <i class="fa fa-pencil-alt me-1 text-primary"></i> Edit
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php 
// ==========================================
// ROUTER: ADMIN ORDERS (MANAGEMENT)
// ==========================================
elseif ($page === 'admin_orders' && is_admin()): ?>
    <h3 class="fw-bold mb-4">Kelola Pesanan Masuk</h3>
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light"><tr><th class="ps-4">ID</th><th>Customer / Penerima</th><th>Total Bayar</th><th class="text-center">Bukti</th><th>Proses Pengiriman</th></tr></thead>
                <tbody>
                    <?php 
                    $res=$conn->query("SELECT * FROM orders ORDER BY id DESC"); 
                    while($o=$res->fetch_assoc()): ?>
                    <tr>
                        <td class="ps-4 fw-bold text-muted">#<?= $o['id'] ?></td>
                        <td>
                            <strong class="d-block"><?= h($o['nama_penerima']) ?></strong>
                            <small class="text-muted"><i class="fa fa-phone me-1"></i><?= $o['telepon_penerima'] ?></small>
                        </td>
                        <td class="fw-bold text-shopee"><?= format_rp($o['total']) ?></td>
                        <td class="text-center">
                            <?php if($o['bukti_pembayaran']): ?>
                                <a href="<?= $o['bukti_pembayaran'] ?>" target="_blank" class="btn btn-xs btn-primary rounded-pill px-3 py-1 shadow-sm" style="font-size: 10px;">CEK BUKTI</a>
                            <?php else: ?>
                                <span class="badge bg-light text-muted border px-3">BELUM ADA</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="action" value="update_status">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <select name="status_pengiriman" class="form-select form-select-sm shadow-none rounded-pill" onchange="this.form.submit()" style="width:180px">
                                    <option value="menunggu konfirmasi" <?= $o['status_pengiriman']=='menunggu konfirmasi'?'selected':'' ?>>⌛ Konfirmasi</option>
                                    <option value="dikemas" <?= $o['status_pengiriman']=='dikemas'?'selected':'' ?>>📦 Dikemas</option>
                                    <option value="dikirim" <?= $o['status_pengiriman']=='dikirim'?'selected':'' ?>>🚚 Dikirim</option>
                                    <option value="selesai" <?= $o['status_pengiriman']=='selesai'?'selected':'' ?>>✅ Selesai</option>
                                </select>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php 
// ==========================================
// ROUTER: ADMIN PAYROLL (EXPENSES)
// ==========================================
elseif ($page === 'admin_payroll' && is_admin()): 
    $filter_kat = $_GET['f_kat'] ?? '';
    $where = $filter_kat ? "WHERE bulan = '$filter_kat'" : "";
?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold">Catatan Biaya Operasional</h3>
        <button class="btn btn-shopee rounded-pill" onclick="expenseModal.show()">
            <i class="fa fa-plus-circle me-2"></i>Tambah Biaya
        </button>
    </div>

    <div class="card border-0 shadow-sm p-4 mb-4 rounded-4">
        <form class="row g-3 align-items-end" method="GET">
            <input type="hidden" name="page" value="admin_payroll">
            <div class="col-md-5">
                <label class="small fw-bold text-muted mb-2">Kategori Pengeluaran</label>
                <select name="f_kat" class="form-select shadow-none rounded-pill">
                    <option value="">Semua Kategori</option>
                    <option value="Gaji Karyawan" <?= $filter_kat=='Gaji Karyawan'?'selected':'' ?>>Gaji Karyawan</option>
                    <option value="Bahan Baku" <?= $filter_kat=='Bahan Baku'?'selected':'' ?>>Bahan Baku</option>
                    <option value="Operasional Toko" <?= $filter_kat=='Operasional Toko'?'selected':'' ?>>Operasional Toko</option>
                    <option value="Pemasaran" <?= $filter_kat=='Pemasaran'?'selected':'' ?>>Pemasaran</option>
                </select>
            </div>
            <div class="col-md-2">
                <button class="btn btn-dark w-100 rounded-pill py-2">Filter Data</button>
            </div>
        </form>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th class="ps-4">Tgl Input</th><th>Keterangan Transaksi</th><th>Kategori</th><th>Total Biaya</th></tr></thead>
            <tbody>
                <?php 
                $res=$conn->query("SELECT * FROM payroll $where ORDER BY id DESC"); 
                while($p=$res->fetch_assoc()): ?>
                <tr>
                    <td class="ps-4 small text-muted"><?= date('d/m/Y', strtotime($p['tanggal_bayar'])) ?></td>
                    <td><strong><?= h($p['nama_karyawan']) ?></strong></td>
                    <td><span class="badge bg-info text-white rounded-pill px-3"><?= $p['bulan'] ?></span></td>
                    <td class="text-danger fw-bold"><?= format_rp($p['gaji_pokok']) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

<?php 
// ==========================================
// ROUTER: ADMIN FINANCE (CASHFLOW)
// ==========================================
elseif ($page === 'admin_finance' && is_admin()): 
    $f_start = $_GET['start'] ?? date('Y-m-01');
    $f_end = $_GET['end'] ?? date('Y-m-d');
?>
    <h3 class="fw-bold mb-4">Laporan Arus Kas</h3>
    
    <div class="card border-0 shadow-sm p-4 mb-4 rounded-4 no-print">
        <form class="row g-3 align-items-end" method="GET">
            <input type="hidden" name="page" value="admin_finance">
            <div class="col-md-4">
                <label class="small fw-bold text-muted mb-2">Tanggal Mulai</label>
                <input type="date" name="start" value="<?= $f_start ?>" class="form-control rounded-pill">
            </div>
            <div class="col-md-4">
                <label class="small fw-bold text-muted mb-2">Tanggal Berakhir</label>
                <input type="date" name="end" value="<?= $f_end ?>" class="form-control rounded-pill">
            </div>
            <div class="col-md-2">
                <button class="btn btn-primary w-100 rounded-pill py-2">Proses</button>
            </div>
        </form>
    </div>

    <div class="card border-0 shadow-sm p-4 rounded-4">
        <div class="d-flex justify-content-between mb-4">
             <h5 class="fw-bold">Rincian Transaksi</h5>
             <span class="small text-muted"><?= date('d/m/y', strtotime($f_start)) ?> - <?= date('d/m/y', strtotime($f_end)) ?></span>
        </div>
        <div class="table-responsive">
            <table class="table align-middle">
                <thead class="table-light"><tr><th>Tanggal</th><th>Jenis</th><th>Keterangan</th><th class="text-success">Pemasukan</th><th class="text-danger">Pengeluaran</th></tr></thead>
                <tbody>
                    <?php 
                    $res=$conn->query("SELECT created_at as tgl, 'PENJUALAN' as tipe, CONCAT('Pesanan #', id) as ket, total as m, 0 as k FROM orders WHERE DATE(created_at) BETWEEN '$f_start' AND '$f_end' 
                                       UNION 
                                       SELECT tanggal_bayar, 'PENGELUARAN' as tipe, nama_karyawan as ket, 0 as m, gaji_pokok as k FROM payroll WHERE DATE(tanggal_bayar) BETWEEN '$f_start' AND '$f_end' 
                                       ORDER BY tgl DESC"); 
                    
                    $total_m = 0; $total_k = 0;
                    while($f=$res->fetch_assoc()): 
                        $total_m += $f['m']; $total_k += $f['k'];
                    ?>
                    <tr class="small">
                        <td><?= date('d M Y', strtotime($f['tgl'])) ?></td>
                        <td><span class="badge bg-<?= $f['tipe']=='PENGELUARAN'?'danger':'success' ?> rounded-pill px-3"><?= $f['tipe'] ?></span></td>
                        <td><?= $f['ket'] ?></td>
                        <td class="text-success"><?= $f['m']>0?format_rp($f['m']):'-' ?></td>
                        <td class="text-danger"><?= $f['k']>0?format_rp($f['k']):'-' ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
                <tfoot class="table-light border-top border-dark">
                    <tr class="fw-bold">
                        <td colspan="3" class="text-end py-3">REKAPITULASI BERSIH:</td>
                        <td class="text-success py-3"><?= format_rp($total_m) ?></td>
                        <td class="text-danger py-3"><?= format_rp($total_k) ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php endif; ?>
</div>

<div class="modal fade" id="modalProduct" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" enctype="multipart/form-data" class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 pb-0 ps-4"><h5 class="fw-bold">Detail Produk</h5><button type="button" class="btn-close shadow-none" data-bs-dismiss="modal"></button></div>
            <div class="modal-body px-4 py-3">
                <input type="hidden" name="action" value="save_product">
                <input type="hidden" name="id" id="prod_id">
                <input type="hidden" name="existing_img" id="prod_img_val">
                <div class="mb-3"><label class="small fw-bold text-muted mb-1">Nama Produk</label><input type="text" name="nama" id="prod_nama" class="form-control rounded-pill shadow-none" required></div>
                <div class="row mb-3">
                    <div class="col"><label class="small fw-bold text-muted mb-1">Harga Modal</label><input type="number" name="harga_modal" id="prod_modal" class="form-control rounded-pill shadow-none" required></div>
                    <div class="col"><label class="small fw-bold text-muted mb-1">Harga Jual</label><input type="number" name="harga_jual" id="prod_jual" class="form-control rounded-pill shadow-none" required></div>
                </div>
                <div class="mb-3"><label class="small fw-bold text-muted mb-1">Stok Tersedia</label><input type="number" name="stok" id="prod_stok" class="form-control rounded-pill shadow-none" required></div>
                <div class="mb-3"><label class="small fw-bold text-muted mb-1">Update Foto Produk</label><input type="file" name="image_file" class="form-control shadow-none rounded-pill" accept="image/*"></div>
                <div class="mb-3"><label class="small fw-bold text-muted mb-1">Deskripsi Singkat</label><textarea name="deskripsi" id="prod_desk" class="form-control rounded-4 shadow-none" rows="3"></textarea></div>
            </div>
            <div class="modal-footer border-0 p-4 pt-0"><button class="btn btn-shopee w-100 py-2 rounded-pill shadow">SIMPAN PERUBAHAN</button></div>
        </form>
    </div>
</div>

<div class="modal fade" id="modalExpense" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 pb-0 ps-4"><h5 class="fw-bold">Input Biaya Baru</h5><button type="button" class="btn-close shadow-none" data-bs-dismiss="modal"></button></div>
            <div class="modal-body px-4 py-3">
                <input type="hidden" name="action" value="save_expense">
                <div class="mb-3"><label class="small fw-bold text-muted mb-1">Keterangan Biaya</label><input type="text" name="keterangan" class="form-control rounded-pill shadow-none" placeholder="Contoh: Beli Terigu 10Kg" required></div>
                <div class="mb-3"><label class="small fw-bold text-muted mb-1">Jumlah Nominal (Rp)</label><input type="number" name="jumlah" class="form-control rounded-pill shadow-none" required></div>
                <div class="mb-3"><label class="small fw-bold text-muted mb-1">Pilih Kategori</label>
                    <select name="kategori" class="form-select rounded-pill shadow-none">
                        <option value="Bahan Baku">Bahan Baku</option>
                        <option value="Gaji Karyawan">Gaji Karyawan</option>
                        <option value="Operasional Toko">Operasional Toko</option>
                        <option value="Pemasaran">Pemasaran</option>
                    </select>
                </div>
                <div class="mb-3"><label class="small fw-bold text-muted mb-1">Tanggal Transaksi</label><input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" class="form-control rounded-pill shadow-none"></div>
            </div>
            <div class="modal-footer border-0 p-4 pt-0"><button class="btn btn-shopee w-100 py-2 rounded-pill shadow">SIMPAN TRANSAKSI</button></div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Inisialisasi Modal
    const prodModal = new bootstrap.Modal(document.getElementById('modalProduct'));
    const expenseModal = new bootstrap.Modal(document.getElementById('modalExpense'));
    
    // Fungsi UI Inventaris
    function showProductModal() { 
        document.getElementById('prod_id').value=''; 
        document.getElementById('prod_nama').value=''; 
        document.getElementById('prod_modal').value='';
        document.getElementById('prod_jual').value='';
        document.getElementById('prod_stok').value='';
        document.getElementById('prod_desk').value='';
        document.getElementById('prod_img_val').value=''; 
        prodModal.show(); 
    }
    
    function editProduct(p) { 
        document.getElementById('prod_id').value=p.id; 
        document.getElementById('prod_nama').value=p.nama; 
        document.getElementById('prod_modal').value=p.harga_modal; 
        document.getElementById('prod_jual').value=p.harga; 
        document.getElementById('prod_stok').value=p.stok; 
        document.getElementById('prod_img_val').value=p.image_url; 
        document.getElementById('prod_desk').value=p.deskripsi; 
        prodModal.show(); 
    }

    // Toggle Box Pembayaran QRIS
    function toggleQR(val) { 
        const box = document.getElementById('qris_box');
        if(val === 'QRIS') box.classList.remove('d-none');
        else box.classList.add('d-none');
    }

    // Real-time Clock (JavaScript)
    function updateClock() {
        const now = new Date();
        const clock = document.getElementById('serverClock');
        if(clock) {
            clock.textContent = now.getHours().toString().padStart(2, '0') + ':' + 
                              now.getMinutes().toString().padStart(2, '0') + ':' + 
                              now.getSeconds().toString().padStart(2, '0');
        }
    }
    setInterval(updateClock, 1000);

    // Inisialisasi Chart Penjualan
    <?php if($page === 'admin_dashboard'): 
        $dates=[]; $sums=[]; 
        for($i=6; $i>=0; $i--) {
            $d = date('Y-m-d', strtotime("-$i days"));
            $dates[] = date('d M', strtotime($d));
            $sums[] = $conn->query("SELECT SUM(total) as n FROM orders WHERE DATE(created_at) = '$d' AND status_pengiriman != 'menunggu konfirmasi'")->fetch_assoc()['n'] ?? 0;
        }
    ?>
    const ctx = document.getElementById('salesChart');
    if(ctx) {
        new Chart(ctx, {
            type: 'line',
            data: { 
                labels: <?= json_encode($dates) ?>, 
                datasets: [{ 
                    label: 'Pendapatan', 
                    data: <?= json_encode($sums) ?>, 
                    borderColor: '#ee4d2d', 
                    tension: 0.4, 
                    fill: true, 
                    backgroundColor: 'rgba(238, 77, 45, 0.1)',
                    pointBackgroundColor: '#ee4d2d',
                    pointRadius: 4
                }] 
            },
            options: { 
                plugins: { legend: { display: false } }, 
                scales: { 
                    y: { 
                        beginAtZero: true,
                        ticks: { callback: function(value) { return 'Rp' + value.toLocaleString(); } }
                    } 
                } 
            }
        });
    }
    <?php endif; ?>
</script>

</body>
</html>