<?php
// index.php
// E-Commerce "Cireng Isi" - Single file starter
// Requirements:
// - PHP 7+
// - MySQL (XAMPP)
// - Folder uploads/ writable

session_start();

/* ----------------------------
  CONFIG: sesuaikan jika perlu
----------------------------- */
$db_host = '127.0.0.1';
$db_user = 'root';
$db_pass = '';
$db_name = 'ecommerce';
$base_url = ''; // jika menggunakan subfolder, isi misalnya '/cireng_store' (opsional)
$upload_dir = __DIR__ . '/uploads';
$upload_url = ($base_url ? $base_url : '') . '/uploads';

/* ----------------------------
  KONEKSI DB
-----------------------------*/
$mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($mysqli->connect_errno) {
    die("Koneksi DB gagal: " . $mysqli->connect_error);
}
$mysqli->set_charset('utf8mb4');

/* HELPER */
function h($s){ return htmlspecialchars($s, ENT_QUOTES); }
function is_logged(){ return isset($_SESSION['user']); } // <--- FUNSI INI DITAMBAHKAN
function is_admin(){ return isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin'; }
function redirect($url){ header("Location: $url"); exit; }
if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

/* ----------------------------
  AUTH: register, login, logout
-----------------------------*/

// Register handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register') {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    if (!$nama || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 4) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Isian tidak valid (nama, email, password minimal 4 karakter).'];
        redirect($_SERVER['PHP_SELF'].'?page=register');
    }
    // check email exist
    $stmt = $mysqli->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
    $stmt->bind_param('s', $email); $stmt->execute(); $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Email sudah terdaftar.'];
        redirect($_SERVER['PHP_SELF'].'?page=register');
    }
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $mysqli->prepare("INSERT INTO users (nama,email,password,role) VALUES (?,?,?, 'customer')");
    $stmt->bind_param('sss', $nama, $email, $hash);
    $stmt->execute();
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Registrasi berhasil. Silakan login.'];
    redirect($_SERVER['PHP_SELF'].'?page=login');
}

// Login handler (both admin and customer)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !$password) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Email atau password tidak valid.'];
        redirect($_SERVER['PHP_SELF'].'?page=login');
    }
    $stmt = $mysqli->prepare("SELECT id,nama,email,password,role FROM users WHERE email=? LIMIT 1");
    $stmt->bind_param('s',$email); $stmt->execute(); $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            unset($row['password']);
            $_SESSION['user'] = $row;
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Login berhasil. Selamat datang, '.$row['nama'].'!'];
            // redirect to admin dashboard if admin
            if ($row['role'] === 'admin') redirect($_SERVER['PHP_SELF'].'?page=admin_dashboard');
            redirect($_SERVER['PHP_SELF']);
        } else {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Password salah.'];
            redirect($_SERVER['PHP_SELF'].'?page=login');
        }
    } else {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Email tidak ditemukan.'];
        redirect($_SERVER['PHP_SELF'].'?page=login');
    }
}

// Logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    session_start();
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Anda berhasil logout.'];
    redirect($_SERVER['PHP_SELF']);
}

/* ----------------------------
  PRODUCT / CATEGORY CRUD (Admin)
  - actions via ?page=admin_products & ?action=...
-----------------------------*/
if (isset($_GET['page']) && strpos($_GET['page'], 'admin_') === 0) {
    if (!is_admin()) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Anda harus login sebagai admin untuk mengakses halaman admin.'];
        redirect($_SERVER['PHP_SELF'].'?page=login');
    }
}

/* Upload helper */
function handle_upload($file_input_name){
    global $upload_dir;
    if (!isset($_FILES[$file_input_name]) || $_FILES[$file_input_name]['error'] !== UPLOAD_ERR_OK) return null;
    $f = $_FILES[$file_input_name];
    $allowed = ['image/png','image/jpeg','image/jpg','image/webp'];
    if (!in_array($f['type'], $allowed)) return null;
    $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
    $fn = uniqid('img_').'.'.$ext;
    $target = $upload_dir . '/' . $fn;
    if (move_uploaded_file($f['tmp_name'], $target)) return $fn;
    return null;
}

/* Admin: add category */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_category') {
    $nama = trim($_POST['nama']);
    $gambar = handle_upload('gambar');
    if (!$nama) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Nama kategori harus diisi.'];
        redirect($_SERVER['PHP_SELF'].'?page=admin_products&tab=categories');
    }
    $stmt = $mysqli->prepare("INSERT INTO categories (nama, gambar) VALUES (?, ?)");
    $stmt->bind_param('ss',$nama,$gambar);
    $stmt->execute();
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Kategori berhasil ditambahkan.'];
    redirect($_SERVER['PHP_SELF'].'?page=admin_products&tab=categories');
}

/* Admin: add/edit/delete product */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_product') {
    $nama = trim($_POST['nama']);
    $deskripsi = trim($_POST['deskripsi']);
    $harga = floatval($_POST['harga']);
    $stok = intval($_POST['stok']);
    $kategori_id = $_POST['kategori_id'] ? intval($_POST['kategori_id']) : NULL;
    $gambar = handle_upload('gambar');

    if (!$nama || $harga <= 0) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Nama & harga wajib diisi (harga > 0).'];
        redirect($_SERVER['PHP_SELF'].'?page=admin_products');
    }
    $stmt = $mysqli->prepare("INSERT INTO products (nama,deskripsi,harga,stok,kategori_id,gambar) VALUES (?,?,?,?,?,?)");
    $stmt->bind_param('ssdiis',$nama,$deskripsi,$harga,$stok,$kategori_id,$gambar);
    $stmt->execute();
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Produk berhasil ditambahkan.'];
    redirect($_SERVER['PHP_SELF'].'?page=admin_products');
}

/* Admin: delete product */
if (isset($_GET['action']) && $_GET['action'] === 'delete_product' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $mysqli->prepare("DELETE FROM products WHERE id=?");
    $stmt->bind_param('i',$id); $stmt->execute();
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Produk dihapus.'];
    redirect($_SERVER['PHP_SELF'].'?page=admin_products');
}

/* Admin: update order status */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_order_status') {
    $order_id = intval($_POST['order_id']);
    $status = trim($_POST['status']);
    $stmt = $mysqli->prepare("UPDATE orders SET status=? WHERE id=?");
    $stmt->bind_param('si',$status,$order_id);
    $stmt->execute();
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Status pesanan diperbarui.'];
    redirect($_SERVER['PHP_SELF'].'?page=admin_orders');
}

/* ----------------------------
  CART (session)
-----------------------------*/
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = []; // cart: product_id => qty

// add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_to_cart') {
    $product_id = intval($_POST['product_id']);
    $qty = max(1, intval($_POST['qty']));
    if (isset($_SESSION['cart'][$product_id])) $_SESSION['cart'][$product_id] += $qty;
    else $_SESSION['cart'][$product_id] = $qty;
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Produk ditambahkan ke keranjang.'];
    redirect($_SERVER['PHP_SELF'].'?page=cart');
}

// update cart quantities
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_cart') {
    foreach ($_POST['qty'] as $pid => $q) {
        $pid = intval($pid); $q = max(0,intval($q));
        if ($q <= 0) unset($_SESSION['cart'][$pid]);
        else $_SESSION['cart'][$pid] = $q;
    }
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Keranjang diperbarui.'];
    redirect($_SERVER['PHP_SELF'].'?page=cart');
}

/* Checkout: create customer, order, order_items */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'checkout') {
    // minimal validation
    $nama = trim($_POST['nama']);
    $alamat = trim($_POST['alamat']);
    $telepon = trim($_POST['telepon']);
    $email = trim($_POST['email']);
    if (!$nama || !$alamat || !$telepon || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Isian checkout tidak lengkap atau format email salah.'];
        redirect($_SERVER['PHP_SELF'].'?page=checkout');
    }
    if (empty($_SESSION['cart'])) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Keranjang kosong.'];
        redirect($_SERVER['PHP_SELF'].'?page=cart');
    }

    // create customer
    $stmt = $mysqli->prepare("INSERT INTO customers (nama,alamat,telepon,email) VALUES (?,?,?,?)");
    $stmt->bind_param('ssss',$nama,$alamat,$telepon,$email);
    $stmt->execute();
    $customer_id = $mysqli->insert_id;

    // calculate total and insert order
    $total = 0.0;
    $cart_items = $_SESSION['cart'];
    // lock? skip for simplicity

    foreach ($cart_items as $pid => $q) {
        $res = $mysqli->query("SELECT id,harga,stok FROM products WHERE id=" . intval($pid) . " LIMIT 1");
        if ($r = $res->fetch_assoc()) {
            $price = floatval($r['harga']);
            $total += $price * $q;
        }
    }
    $tanggal = date('Y-m-d H:i:s');
    $status = 'pending';
    $stmt = $mysqli->prepare("INSERT INTO orders (customer_id,tanggal,status,total) VALUES (?,?,?,?)");
    $stmt->bind_param('issd', $customer_id, $tanggal, $status, $total);
    $stmt->execute();
    $order_id = $mysqli->insert_id;

    // insert order_items and reduce stock
    foreach ($cart_items as $pid => $q) {
        $res = $mysqli->query("SELECT id,harga,stok FROM products WHERE id=" . intval($pid) . " LIMIT 1");
        if ($r = $res->fetch_assoc()) {
            $price = floatval($r['harga']);
            $stmt = $mysqli->prepare("INSERT INTO order_items (order_id,product_id,qty,harga) VALUES (?,?,?,?)");
            $stmt->bind_param('iiid', $order_id, $pid, $q, $price);
            $stmt->execute();
            // update stock
            $newstok = max(0, intval($r['stok']) - $q);
            $stmt2 = $mysqli->prepare("UPDATE products SET stok=? WHERE id=?");
            $stmt2->bind_param('ii',$newstok,$pid); $stmt2->execute();
        }
    }

    // optional: create dummy payment/shipments rows - skipped for brevity

    // clear cart
    $_SESSION['cart'] = [];
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Checkout sukses. Pesanan ID: '.$order_id];
    redirect($_SERVER['PHP_SELF'].'?page=orders&order_id='.$order_id);
}

/* ----------------------------
  SMALL QUERIES FOR FRONTEND
-----------------------------*/
function get_categories($mysqli){
    $res = $mysqli->query("SELECT * FROM categories ORDER BY nama ASC");
    return $res->fetch_all(MYSQLI_ASSOC);
}
function get_products($mysqli, $search = '', $cat = null){
    $sql = "SELECT p.*, c.nama as kategori_nama FROM products p LEFT JOIN categories c ON p.kategori_id=c.id WHERE 1=1 ";
    $params = [];
    if ($search) {
        $s = $mysqli->real_escape_string('%'.$search.'%');
        $sql .= " AND (p.nama LIKE '{$s}' OR p.deskripsi LIKE '{$s}') ";
    }
    if ($cat) {
        $cat = intval($cat);
        $sql .= " AND p.kategori_id = {$cat} ";
    }
    $sql .= " ORDER BY p.id DESC LIMIT 200";
    $res = $mysqli->query($sql);
    return $res->fetch_all(MYSQLI_ASSOC);
}

/* ----------------------------
  FLASH MESSAGE helper
-----------------------------*/
function flash_html(){
    if (!isset($_SESSION['flash'])) return '';
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
    $type = $f['type']; $msg = $f['msg'];
    $icon = $type === 'success' ? 'check-circle' : 'exclamation-triangle';
    return "<script>document.addEventListener('DOMContentLoaded', function(){ Swal.fire({icon:'".($type==='success'?'success':'error')."', title:'', text:'".addslashes($msg)."'}); });</script>";
}

/* ----------------------------
  RENDER HTML PAGE
-----------------------------*/
?><!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Chireng Easy</title>
<!-- Bootstrap 5 CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Google Fonts Poppins -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<!-- Font Awesome -->
<script src="https://kit.fontawesome.com/a0b6b6b6b6.js" crossorigin="anonymous"></script>
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
body { font-family: 'Poppins', sans-serif; background:#f6fff7; color:#1b3a2d;}
.navbar-brand { font-weight:700; color:#1b5e20; }
.card { border: none; border-radius:12px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); }
.btn-primary { background:#2e7d32; border-color:#2e7d32; }
.bg-banner { background: linear-gradient(90deg, rgba(46,125,50,0.08), rgba(255,255,255,0.0)); padding:40px 0; }
.footer { padding:20px 0; text-align:center; color:#6b6b6b; }
.badge-stock { background:#e8f5e9; color:#2e7d32; border-radius:6px; padding:6px; }
</style>
</head>
<body>
<!-- NAVBAR -->
 <?php
$page = $_GET['page'] ?? '';

echo flash_html();

// === ADMIN: HALAMAN PRODUK ===
if ($page === 'admin_products' && is_admin()) {
    $categories = get_categories($mysqli);
    $products = get_products($mysqli);
?>

<div class="container my-4">
    <h3 class="mb-3">Kelola Produk</h3>

    <div class="card p-4 mb-4">
        <h5>Tambah Produk Baru</h5>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="add_product">
            <div class="mb-2">
                <label>Nama Produk</label>
                <input type="text" name="nama" class="form-control" required>
            </div>
            <div class="mb-2">
                <label>Deskripsi</label>
                <textarea name="deskripsi" class="form-control"></textarea>
            </div>
            <div class="mb-2">
                <label>Harga</label>
                <input type="number" step="0.01" name="harga" class="form-control" required>
            </div>
            <div class="mb-2">
                <label>Stok</label>
                <input type="number" name="stok" class="form-control" required>
            </div>
            <div class="mb-2">
                <label>Kategori</label>
                <select name="kategori_id" class="form-select">
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>"><?= h($cat['nama']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-2">
                <label>Gambar Produk</label>
                <input type="file" name="gambar" class="form-control" accept="image/*">
            </div>
            <button type="submit" class="btn btn-success mt-2">Tambah Produk</button>
        </form>
    </div>

    <div class="card p-3">
        <h5>Daftar Produk</h5>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Gambar</th>
                    <th>Nama</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $p): ?>
                <tr>
                    <td>
                        <?php if ($p['gambar']): ?>
                            <img src="uploads/<?= h($p['gambar']) ?>" width="60">
                        <?php else: ?>
                            <small>Tidak ada</small>
                        <?php endif; ?>
                    </td>
                    <td><?= h($p['nama']) ?></td>
                    <td><?= h($p['kategori_nama'] ?? '-') ?></td>
                    <td>Rp<?= number_format($p['harga'],0,',','.') ?></td>
                    <td><?= $p['stok'] ?></td>
                    <td>
                        <a href="?action=delete_product&id=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus produk ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php
}
// === END ADMIN ===
?>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="<?php echo $_SERVER['PHP_SELF']; ?>">Chireng Easy</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo $_SERVER['PHP_SELF']; ?>">Home</a>
        </li>

        <?php if (!is_admin()): // hanya tampil untuk customer ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo $_SERVER['PHP_SELF']; ?>?page=cart">
              Keranjang (<?php echo array_sum($_SESSION['cart'] ?? []); ?>)
            </a>
          </li>
        <?php endif; ?>

        <?php if (is_admin()): ?>
    <li class="nav-item"><a class="nav-link" href="<?php echo $_SERVER['PHP_SELF']; ?>?page=categories">Kategori</a></li>
<?php endif; ?>

      </ul>

      <ul class="navbar-nav ms-auto">
        <?php if (!empty($_SESSION['user'])): ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo $_SERVER['PHP_SELF']; ?>?page=logout">Logout</a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo $_SERVER['PHP_SELF']; ?>?page=login">Login</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>


<!-- flash -->
<?php echo flash_html(); ?>

<div class="container mt-4 mb-5">
<?php
/* ----------------------------
  ROUTING SEDERHANA via $_GET['page']
-----------------------------*/
$page = $_GET['page'] ?? 'home';

if ($page === 'home') {
    // HOME: banner + produk grid + search + categories filter
    $q = $_GET['q'] ?? '';
    $cat = isset($_GET['cat']) ? intval($_GET['cat']) : null;
    $categories = get_categories($mysqli);
    $products = get_products($mysqli, $q, $cat);
    ?>
    <div class="row align-items-center bg-banner rounded p-4 mb-4">
      <div class="col-md-7">
        <h1 class="display-6">Chireng Easy</h1>
        <p class="lead text-muted">Ngemil Lebih Easy Bareng Chireng Easy!</p>
        <a href="#products" class="btn btn-primary">Beli Sekarang</a>
      </div>
      <div class="col-md-5 text-center">
        <img src="db_cireng/images.jpeg" style="max-width:100%; border-radius:12px;" alt="images">
      </div>
    </div>

    <div class="row mb-3">
      <div class="col-md-8">
        <form class="d-flex" method="get" action="">
            <input type="hidden" name="page" value="home">
            <input class="form-control me-2" type="search" name="q" placeholder="Cari produk..." value="<?php echo h($q); ?>">
            <button class="btn btn-outline-success" type="submit">Cari</button>
        </form>
      </div>
      <div class="col-md-4 text-end">
        <div class="btn-group">
          <button class="btn btn-sm btn-light dropdown-toggle" data-bs-toggle="dropdown">Kategori</button>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?php echo $_SERVER['PHP_SELF']; ?>">Semua</a></li>
            <?php foreach($categories as $c): ?>
                <li><a class="dropdown-item" href="<?php echo $_SERVER['PHP_SELF']; ?>?cat=<?php echo $c['id']; ?>"><?php echo h($c['nama']); ?></a></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    </div>

    <div id="products" class="row g-3">
      <?php if (empty($products)): ?>
        <div class="col-12"><div class="alert alert-info">Tidak ada produk.</div></div>
      <?php endif; ?>
      <?php foreach($products as $p): ?>
        <div class="col-sm-6 col-md-4 col-lg-3">
          <div class="card">
            <?php if ($p['gambar']): ?>
              <img src="uploads/<?php echo h($p['gambar']); ?>" class="card-img-top" style="height:160px; object-fit:cover; border-top-left-radius:12px; border-top-right-radius:12px;">
            <?php else: ?>
              <div style="height:160px; background:#f1f8f2; display:flex; align-items:center; justify-content:center; color:#7b7b7b; border-top-left-radius:12px; border-top-right-radius:12px;">
                <i class="fa fa-box-open fa-2x"></i>
              </div>
            <?php endif; ?>
            <div class="card-body">
              <h5 class="card-title"><?php echo h($p['nama']); ?></h5>
              <p class="card-text text-muted" style="font-size:13px;"><?php echo substr(h($p['deskripsi']),0,80); ?>...</p>
              <div class="d-flex justify-content-between align-items-center mb-2">
                <div><strong>Rp <?php echo number_format($p['harga'],0,',','.'); ?></strong></div>
                <div class="badge-stock"><?php echo intval($p['stok'])>0 ? intval($p['stok']).' stk' : 'Habis'; ?></div>
              </div>
              <div class="d-flex">
                <form method="post" class="me-2">
                  <input type="hidden" name="action" value="add_to_cart">
                  <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                  <input type="number" name="qty" value="1" min="1" class="form-control form-control-sm me-2" style="width:80px;">
                  <button class="btn btn-sm btn-primary" <?php echo intval($p['stok'])<=0 ? 'disabled' : ''; ?>><i class="fa fa-cart-plus"></i> Tambah</button>
                </form>
                <a class="btn btn-sm btn-outline-secondary" href="<?php echo $_SERVER['PHP_SELF']; ?>?page=product&id=<?php echo $p['id']; ?>">Detail</a>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <?php
}

/* Product detail */
elseif ($page === 'product' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $res = $mysqli->query("SELECT p.*, c.nama as kategori_nama FROM products p LEFT JOIN categories c ON p.kategori_id=c.id WHERE p.id={$id} LIMIT 1");
    $p = $res->fetch_assoc();
    if (!$p) {
        echo '<div class="alert alert-danger">Produk tidak ditemukan.</div>';
    } else {
    ?>
    <div class="row">
      <div class="col-md-6">
        <?php if ($p['gambar']): ?>
            <img src="uploads/<?php echo h($p['gambar']); ?>" class="img-fluid rounded">
        <?php else: ?>
            <div style="height:320px;background:#f1f8f2;display:flex;align-items:center;justify-content:center;border-radius:8px;">
                <i class="fa fa-box-open fa-3x"></i>
            </div>
        <?php endif; ?>
      </div>
      <div class="col-md-6">
        <h2><?php echo h($p['nama']); ?></h2>
        <p class="text-muted"><?php echo h($p['kategori_nama']); ?></p>
        <h4 class="text-success">Rp <?php echo number_format($p['harga'],0,',','.'); ?></h4>
        <p><?php echo nl2br(h($p['deskripsi'])); ?></p>
        <p>Stok: <?php echo intval($p['stok']); ?></p>
        <form method="post" class="d-flex align-items-center">
          <input type="hidden" name="action" value="add_to_cart">
          <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
          <input type="number" name="qty" value="1" min="1" class="form-control me-2" style="width:100px;">
          <button class="btn btn-primary" <?php echo intval($p['stok'])<=0 ? 'disabled' : ''; ?>>Tambah ke Keranjang</button>
        </form>
      </div>
    </div>
    <?php
    }
}

/* Cart */
elseif ($page === 'cart') {
    $cart = $_SESSION['cart'] ?? [];
    if ($cart) {
        $ids = implode(',', array_map('intval', array_keys($cart)));
        $res = $mysqli->query("SELECT * FROM products WHERE id IN ({$ids})");
        $rows = [];
        while($r=$res->fetch_assoc()) $rows[$r['id']] = $r;
    } else $rows = [];
    ?>
    <h3>Keranjang Belanja</h3>
    <form method="post">
      <input type="hidden" name="action" value="update_cart">
    <div class="table-responsive">
      <table class="table table-striped">
        <thead><tr><th>Produk</th><th>Harga</th><th>Qty</th><th>Subtotal</th><th></th></tr></thead>
        <tbody>
        <?php $total = 0; if (!$cart): ?>
          <tr><td colspan="5">Keranjang kosong</td></tr>
        <?php else: foreach($cart as $pid => $qty): $p = $rows[$pid]; $subtotal = $p['harga'] * $qty; $total += $subtotal; ?>
          <tr>
            <td><?php echo h($p['nama']); ?></td>
            <td>Rp <?php echo number_format($p['harga'],0,',','.'); ?></td>
            <td><input type="number" name="qty[<?php echo $pid; ?>]" value="<?php echo $qty; ?>" min="0" style="width:80px;"></td>
            <td>Rp <?php echo number_format($subtotal,0,',','.'); ?></td>
            <td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=cart&remove=<?php echo $pid; ?>" class="btn btn-sm btn-danger">Hapus</a></td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
        <tfoot>
          <tr><td colspan="3" class="text-end"><strong>Total:</strong></td><td colspan="2"><strong>Rp <?php echo number_format($total,0,',','.'); ?></strong></td></tr>
        </tfoot>
      </table>
    </div>
    <div class="d-flex justify-content-between">
      <div>
        <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="btn btn-outline-secondary">Lanjut Belanja</a>
      </div>
      <div>
        <button class="btn btn-primary">Update Keranjang</button>
        <a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=checkout" class="btn btn-success">Checkout</a>
      </div>
    </div>
    </form>
    <?php
    // remove single item
    if (isset($_GET['remove'])) {
        $rid = intval($_GET['remove']);
        unset($_SESSION['cart'][$rid]);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Item dihapus dari keranjang.'];
        redirect($_SERVER['PHP_SELF'].'?page=cart');
    }
}

/* Checkout page */
elseif ($page === 'checkout') {
    if (empty($_SESSION['cart'])) {
        echo '<div class="alert alert-warning">Keranjang kosong. <a href="'.$_SERVER['PHP_SELF'].'">Kembali</a></div>';
    } else {
        // show simple checkout form
        ?>
        <h3>Checkout</h3>
        <form method="post">
          <input type="hidden" name="action" value="checkout">
          <div class="mb-3">
            <label>Nama Penerima</label>
            <input type="text" name="nama" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Alamat</label>
            <textarea name="alamat" class="form-control" required></textarea>
          </div>
          <div class="mb-3">
            <label>Telepon</label>
            <input type="text" name="telepon" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
          </div>
          <button class="btn btn-success">Checkout Sekarang</button>
        </form>
        <?php
    }
}

/* Orders for customer */
elseif ($page === 'orders') {
    // show last order if order_id param
    if (isset($_GET['order_id'])) {
        $order_id = intval($_GET['order_id']);
        $res = $mysqli->query("SELECT o.*, c.nama as cust_nama, c.alamat, c.telepon, c.email FROM orders o LEFT JOIN customers c ON o.customer_id=c.id WHERE o.id={$order_id} LIMIT 1");
        $o = $res->fetch_assoc();
        if (!$o) echo '<div class="alert alert-danger">Pesanan tidak ditemukan.</div>';
        else {
            $res2 = $mysqli->query("SELECT oi.*, p.nama FROM order_items oi LEFT JOIN products p ON oi.product_id=p.id WHERE oi.order_id={$order_id}");
            ?>
            <h3>Detail Pesanan #<?php echo $o['id']; ?></h3>
            <p>Nama: <?php echo h($o['cust_nama']); ?> | Tanggal: <?php echo h($o['tanggal']); ?> | Status: <?php echo h($o['status']); ?></p>
            <table class="table">
              <thead><tr><th>Produk</th><th>Qty</th><th>Harga</th></tr></thead>
              <tbody>
              <?php while($it=$res2->fetch_assoc()): ?>
                <tr><td><?php echo h($it['nama']); ?></td><td><?php echo $it['qty']; ?></td><td>Rp <?php echo number_format($it['harga'],0,',','.'); ?></td></tr>
              <?php endwhile; ?>
              </tbody>
            </table>
            <div class="alert alert-success">Total: Rp <?php echo number_format($o['total'],0,',','.'); ?></div>
            <?php
        }
    } else {
        echo '<div class="alert alert-info">Riwayat pesanan akan tampil di sini setelah checkout.</div>';
    }
}

/* AUTH PAGES: login & register */
elseif ($page === 'login') {
    ?>
    <div class="row justify-content-center">
      <div class="col-md-6">
        <h3>Login</h3>
        <form method="post">
          <input type="hidden" name="action" value="login">
          <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <button class="btn btn-primary">Login</button>
          <a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=register" class="btn btn-link">Register</a>
        </form>
      </div>
    </div>
    <?php
}
elseif ($page === 'register') {
    ?>
    <div class="row justify-content-center">
      <div class="col-md-6">
        <h3>Register</h3>
        <form method="post">
          <input type="hidden" name="action" value="register">
          <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <button class="btn btn-success">Daftar</button>
        </form>
      </div>
    </div>
    <?php
}

/* ----------------------------
   ADMIN: dashboard, products, orders, users
-----------------------------*/
elseif ($page === 'admin_dashboard') {
    // stats: total products, total orders, total customers, recent orders
    $pcount = $mysqli->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
    $ocount = $mysqli->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'];
    $ccount = $mysqli->query("SELECT COUNT(*) as c FROM customers")->fetch_assoc()['c'];
    $recent = $mysqli->query("SELECT o.*, c.nama as cust_name FROM orders o LEFT JOIN customers c ON o.customer_id=c.id ORDER BY o.tanggal DESC LIMIT 8");
    ?>
    <h3>Admin Dashboard</h3>
    <div class="row g-3 mb-4">
      <div class="col-md-4"><div class="card p-3"><h5>Produk</h5><h2><?php echo $pcount; ?></h2></div></div>
      <div class="col-md-4"><div class="card p-3"><h5>Pesanan</h5><h2><?php echo $ocount; ?></h2></div></div>
      <div class="col-md-4"><div class="card p-3"><h5>Pelanggan</h5><h2><?php echo $ccount; ?></h2></div></div>
    </div>

    <h5>Pesanan Terbaru</h5>
    <table class="table">
      <thead><tr><th>ID</th><th>Pelanggan</th><th>Tanggal</th><th>Status</th><th>Total</th><th></th></tr></thead>
      <tbody>
        <?php while($r = $recent->fetch_assoc()): ?>
          <tr>
            <td><?php echo $r['id']; ?></td>
            <td><?php echo h($r['cust_name']); ?></td>
            <td><?php echo $r['tanggal']; ?></td>
            <td><?php echo h($r['status']); ?></td>
            <td>Rp <?php echo number_format($r['total'],0,',','.'); ?></td>
            <td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=admin_orders" class="btn btn-sm btn-outline-secondary">Kelola</a></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>

    <?php
}

elseif ($page === 'admin_products') {
    // show products + category tab
    $tab = $_GET['tab'] ?? 'products';
    if ($tab === 'categories') {
        // list categories
        $cats = get_categories($mysqli);
        ?>
        <h3>Kelola Kategori</h3>
        <form method="post" enctype="multipart/form-data" class="mb-3">
          <input type="hidden" name="action" value="add_category">
          <div class="row">
            <div class="col-md-4"><input type="text" name="nama" class="form-control" placeholder="Nama kategori"></div>
            <div class="col-md-4"><input type="file" name="gambar" class="form-control"></div>
            <div class="col-md-4"><button class="btn btn-primary">Tambah Kategori</button></div>
          </div>
        </form>
        <table class="table">
          <thead><tr><th>Nama</th><th>Gambar</th></tr></thead>
          <tbody>
            <?php foreach($cats as $c): ?>
              <tr>
                <td><?php echo h($c['nama']); ?></td>
                <td><?php if($c['gambar']): ?><img src="uploads/<?php echo h($c['gambar']); ?>" style="height:48px;"><?php endif; ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=admin_products" class="btn btn-outline-secondary">Kembali</a>
        <?php
    } else {
        // products list + add product form
        $cats = get_categories($mysqli);
        $res = $mysqli->query("SELECT p.*, c.nama AS kategori_nama FROM products p LEFT JOIN categories c ON p.kategori_id=c.id ORDER BY p.id DESC");
        ?>
        <h3>Kelola Produk</h3>
        <button class="btn btn-success mb-3" onclick="document.getElementById('formAdd').style.display='block'">+ Tambah Produk</button>
        <a class="btn btn-outline-secondary mb-3" href="<?php echo $_SERVER['PHP_SELF']; ?>?page=admin_products&tab=categories">Kelola Kategori</a>

        <div id="formAdd" style="display:none;">
          <form method="post" enctype="multipart/form-data" class="card p-3 mb-4">
            <input type="hidden" name="action" value="add_product">
            <div class="row g-2">
              <div class="col-md-4"><input class="form-control" name="nama" placeholder="Nama produk"></div>
              <div class="col-md-4"><input class="form-control" name="harga" placeholder="Harga" type="number" step="0.01"></div>
              <div class="col-md-2"><input class="form-control" name="stok" placeholder="Stok" type="number"></div>
              <div class="col-md-2"><select class="form-control" name="kategori_id"><option value="">--Kategori--</option><?php foreach($cats as $c) echo '<option value="'.$c['id'].'">'.h($c['nama']).'</option>'; ?></select></div>
              <div class="col-md-12"><textarea class="form-control" name="deskripsi" placeholder="Deskripsi"></textarea></div>
              <div class="col-md-6"><input type="file" name="gambar" class="form-control"></div>
              <div class="col-md-6 text-end"><button class="btn btn-primary">Simpan Produk</button></div>
            </div>
          </form>
        </div>

        <table class="table table-striped">
          <thead><tr><th>ID</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th></th></tr></thead>
          <tbody>
            <?php while($p = $res->fetch_assoc()): ?>
              <tr>
                <td><?php echo $p['id']; ?></td>
                <td><?php echo h($p['nama']); ?></td>
                <td><?php echo h($p['kategori_nama']); ?></td>
                <td>Rp <?php echo number_format($p['harga'],0,',','.'); ?></td>
                <td><?php echo $p['stok']; ?></td>
                <td>
                  <a href="<?php echo $_SERVER['PHP_SELF']; ?>?action=delete_product&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin hapus?')">Hapus</a>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
        <?php
    }
}

elseif ($page === 'admin_orders') {
    $res = $mysqli->query("SELECT o.*, c.nama as cust_name FROM orders o LEFT JOIN customers c ON o.customer_id=c.id ORDER BY o.tanggal DESC");
    ?>
    <h3>Kelola Pesanan</h3>
    <table class="table">
      <thead><tr><th>ID</th><th>Pelanggan</th><th>Tanggal</th><th>Status</th><th>Total</th><th>Aksi</th></tr></thead>
      <tbody>
        <?php while($r = $res->fetch_assoc()): ?>
          <tr>
            <td><?php echo $r['id']; ?></td>
            <td><?php echo h($r['cust_name']); ?></td>
            <td><?php echo $r['tanggal']; ?></td>
            <td><?php echo h($r['status']); ?></td>
            <td>Rp <?php echo number_format($r['total'],0,',','.'); ?></td>
            <td>
              <a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=admin_orders&view=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-secondary">Lihat</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php
    if (isset($_GET['view'])) {
        $oid = intval($_GET['view']);
        $o = $mysqli->query("SELECT o.*, c.* FROM orders o LEFT JOIN customers c ON o.customer_id=c.id WHERE o.id={$oid}")->fetch_assoc();
        $items = $mysqli->query("SELECT oi.*, p.nama FROM order_items oi LEFT JOIN products p ON oi.product_id=p.id WHERE oi.order_id={$oid}");
        ?>
        <h5>Detail Pesanan #<?php echo $oid; ?></h5>
        <p>Nama: <?php echo h($o['nama']); ?> | Alamat: <?php echo h($o['alamat']); ?> | Telepon: <?php echo h($o['telepon']); ?></p>
        <table class="table">
          <thead><tr><th>Produk</th><th>Qty</th><th>Harga</th></tr></thead>
          <tbody>
            <?php while($it=$items->fetch_assoc()): ?>
              <tr><td><?php echo h($it['nama']); ?></td><td><?php echo $it['qty']; ?></td><td>Rp <?php echo number_format($it['harga'],0,',','.'); ?></td></tr>
            <?php endwhile; ?>
          </tbody>
        </table>
        <form method="post" class="mb-3">
          <input type="hidden" name="action" value="update_order_status">
          <input type="hidden" name="order_id" value="<?php echo $oid; ?>">
          <select name="status" class="form-control" style="width:200px; display:inline-block;">
            <?php $statuses = ['pending','dikirim','selesai','batal']; foreach($statuses as $st) echo '<option '.($o['status']==$st?'selected':'').' value="'.$st.'">'.ucfirst($st).'</option>'; ?>
          </select>
          <button class="btn btn-primary">Update Status</button>
        </form>
        <?php
    }
}

elseif ($page === 'admin_users') {
    $res = $mysqli->query("SELECT * FROM customers ORDER BY id DESC");
    ?>
    <h3>Daftar Pelanggan</h3>
    <table class="table">
      <thead><tr><th>ID</th><th>Nama</th><th>Email</th><th>Telepon</th></tr></thead>
      <tbody>
        <?php while($r=$res->fetch_assoc()): ?>
          <tr><td><?php echo $r['id']; ?></td><td><?php echo h($r['nama']); ?></td><td><?php echo h($r['email']); ?></td><td><?php echo h($r['telepon']); ?></td></tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php
}

/* Default: unknown page */
else {
    echo '<div class="alert alert-danger">Halaman tidak ditemukan.</div>';
}

/* End container */
?>
</div>

<!-- FOOTER -->
<div class="footer bg-white shadow-sm">
  <div class="container">
    <small>© <?php echo date('Y'); ?> Cireng Isi Lezat — Demo. Built with ❤️</small>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
