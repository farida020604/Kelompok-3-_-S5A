<?php
$password_plain = 'admin123';
$password_hash = password_hash($password_plain, PASSWORD_DEFAULT);
echo "Password Plain: " . $password_plain . "<br>";
echo "Hash Baru: " . $password_hash . "<br>";
?>